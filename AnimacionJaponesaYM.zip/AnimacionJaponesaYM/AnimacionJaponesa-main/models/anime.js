class Anime {
    constructor(nombre, genero, año, autor) {
      this.nombre = nombre;
      this.genero = genero;
      this.año = año;
      this.autor = autor;
    }
  }
  
  module.exports = Anime;